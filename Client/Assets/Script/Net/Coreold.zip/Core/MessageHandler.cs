﻿using UnityEngine;
using System.Collections;
using Protocol;

public delegate void NetworkHandler(int connID, byte[] data);

