﻿using UnityEngine;
using System; 
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class NetworkManager: GTSingleton<NetworkManager>
{
    private Dictionary<int, CliConnection> m_MapCliConnection = new Dictionary<int, CliConnection>();
    private Dictionary<MessageID, NetworkHandler> mMessageDispatchs = new Dictionary<MessageID, NetworkHandler>();

    public void Connect(int connid, string ip, int port)
    {
        if (connid <= 0)
        {
            return;
        }

        CliConnection tempClient = null;
        m_MapCliConnection.TryGetValue(connid, out tempClient);
        if (tempClient != null)
        {
            tempClient->ConnectToServer(ip, port);
        }
        else
        {
            tempClient = new CliConnection(connid);
            tempClient.ConnectToServer(ip, port);
        }
    }


    CliConnection GetConnectionByID(int connID)
    {
        CliConnection tempClient = null;
        m_MapCliConnection.TryGetValue(connID, out tempClient);
        return tempClient;
    }


    public void CloseConntion(int connID)
    {
        CliConnection tempClient = null;
        m_MapCliConnection.TryGetValue(connID, out tempClient);
        if (tempClient != null)
        {
            tempClient->Close();
        }

        return;
    }

    void OnDestroy()
    {
        
    }

    void Update()
    {
        if (s_ClientConnector != null)
        {
            s_ClientConnector.Render();
        }
    }
}
